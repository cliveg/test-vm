{
  param ($MachineName)

  Node $MachineName
  {
	Script ConfigureCPU { 
		SetScript = { 

		  # Set PowerPlan to "High Performance"
			$guid = (Get-WmiObject -Class Win32_PowerPlan -Namespace root\cimv2\power -Filter "ElementName='High Performance'").InstanceID.ToString()
			$regex = [regex]"{(.*?)}$"
			$plan = $regex.Match($guid).groups[1].value
			powercfg -S $plan
}
	}
  }
} 

