Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
		#Nothing to see here
        Write-Verbose "Log write"

	    Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, xDisk, xCredSSP, cDisk, xNetworking
		Write-Verbose "Log write2"
		Set-PowerPlan "High Performance"
		Write-Verbose "Log write3"
  }
} 

function Set-PowerPlan {
	<#
	.SYNOPSIS
		Configures the Power Plan on the local machine. Called from Set-HighPower.

	.DESCRIPTION
		Configures the Power Plan on the local machine. Called from Set-HighPower.

	.NOTES
	  Version							: 1.2
		Wish list						: Better error trapping
	  Rights Required			: Local administrator on server
	  Sched Task Required	: No
	  Lync Server Version	: N/A
	  Author/Copyright		: � Pat Richard, Lync MVP - All Rights Reserved
	  Email/Blog/Twitter	: pat@innervation.com 	http://www.ehloworld.com @patrichard
	  Dedicated Post			:	http://www.ehloworld.com/2558
	  Disclaimer   				: You running this script means you won't blame me if this breaks your stuff. This script is
	  											provided AS IS without warranty of any kind. I disclaim all implied warranties including,
	  											without limitation, any implied warranties of merchantability or of fitness for a particular
	  											purpose. The entire risk arising out of the use or performance of the sample scripts and
	  											documentation remains with you. In no event shall I be liable for any damages whatsoever
	  											(including, without limitation, damages for loss of business profits, business interruption,
	  											loss of business information, or other pecuniary loss) arising out of the use of or inability
	  											to use the script or documentation.
	  Acknowledgements 		:
	  Assumptions					: ExecutionPolicy of AllSigned (recommended), RemoteSigned or Unrestricted (not recommended)
	  Limitations					:
	  Known issues				:

	.LINK
		http://www.ehloworld.com/2558

	.EXAMPLE
	  .\

	  Description
		-----------


	.INPUTS
		None. You cannot pipe objects to this script.
	#>
	[CmdletBinding(SupportsShouldProcess = $True, SupportsPaging = $True)]
	param (
		# Defines the power plan the set the computer to
		[ValidateSet("High performance", "Balanced", "Power saver")]
		[ValidateNotNullOrEmpty()]
		[string] $PreferredPlan = "High Performance"
	)

	Write-Log -Message "Setting power plan to `"$PreferredPlan`"" -NoConsole -Indent 1
	$guid = (Get-WmiObject -Class Win32_PowerPlan -Namespace root\cimv2\power -Filter "ElementName='$PreferredPlan'").InstanceID.ToString()
	$regex = [regex]"{(.*?)}$"
	$plan = $regex.Match($guid).groups[1].value

	powercfg -S $plan
	$Output = "Power plan set to "
	$Output += "`"" + ((Get-WmiObject -Class Win32_PowerPlan -Namespace root\cimv2\power -Filter "IsActive='$True'").ElementName) + "`""
	Write-Log -Message $Output -NoConsole -Indent 1
} # end function Set-PowerPlan
