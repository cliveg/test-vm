Configuration ContosoWebsite
{
  param ($MachineName)

  Node ($MachineName)
  {
     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }


   #script block to download apps and install them
    Script DownloadSilverlight
    {
        GetScript = {
            @{
                Result = "SilverlightInstall"
            }
        }
        TestScript = {
            Test-Path "C:\WindowsAzure\wpilauncher.exe"
        }
        SetScript ={
            $source = "http://download.microsoft.com/download/F/8/C/F8C0EACB-92D0-4722-9B18-965DD2A681E9/30514.00/Silverlight_x64.exe"
            $destination = "C:\WindowsAzure\Silverlight_x64.exe"
            Invoke-WebRequest $source -OutFile $destination
        }
    }

    Package Silverlight_Installation
        {
            Ensure = "Present"
            Name = "Microsoft Silverlight 5"
            Path = "C:\WindowsAzure\Silverlight_x64.exe"
            ProductId = '89F4137D-6C26-4A84-BDB8-2E5A4BB71E00'
            Arguments = '/q'
        }


	Script ConfigureCPU
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={

		  # Set PowerPlan to "High Performance"
			$guid = (Get-WmiObject -Class Win32_PowerPlan -Namespace root\cimv2\power -Filter "ElementName='High Performance'").InstanceID.ToString()
			$regex = [regex]"{(.*?)}$"
			$plan = $regex.Match($guid).groups[1].value
			powercfg -S $plan
		}
	}



  }
} 