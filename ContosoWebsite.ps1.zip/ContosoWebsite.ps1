Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
  }
} 