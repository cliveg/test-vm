Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
    #Nothing to see here
        Write-Verbose "Log write"

	    Import-DscResource -ModuleName xComputerManagement, xActiveDirectory, xDisk, xCredSSP, cDisk, xNetworking
		Write-Verbose "Log write2"

  }
} 

